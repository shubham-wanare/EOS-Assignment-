#include<stdio.h>


int main()

{

    int a=10, b=12;

    printf("%d\n,%d\n,%d\n,%d\n",a+b,a-b,a*b,a/b);

    return 0;

}