#include<stdio.h>

int main(int argc,char const *argv[])

{

    print("hello");
    
    return 0;

}